Users = {
        1234: {
            'name': 'vitoria',
            'email': 'vitoriabarbosas@fiap.com',
            'tickets_disponiveis': 4,
            'tickets_utilizados': 40,
            'saldo_diponivel': 20
        },
        1235: {
            'name': 'matheus',
            'email': 'matheuslemes@fiap.com',
            'tickets_disponiveis': 7,
            'tickets_utilizados': 50,
            'saldo_diponivel': 20
        }
}

